//! solana-sdk Javascript interface
#![cfg(target_arch = "wasm32")]

pub mod keypair;
pub mod transaction;
